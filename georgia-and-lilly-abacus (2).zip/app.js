// Constants & Configuration
const COLUMN_NAMES = ['Ones', 'Tens', 'Hundreds', 'Thousands'];
const COLUMN_MULTIPLIERS = [1, 10, 100, 1000];
const COLUMN_COLORS = ['#eab308', '#22c55e', '#3b82f6', '#ef4444'];
const CONFIG = {
    width: 700,
    height: 500,
    padding: 60,
    beadWidth: 40,
    beadHeight: 35,
    rodThickness: 8,
    extraLeftPadding: 60
};

// Application State
let state = {
    currentUser: localStorage.getItem('abacus_user') || null,
    counts: [0, 0, 0, 0], // Ones, Tens, Hundreds, Thousands
    voiceEnabled: false,
    soundEnabled: true,
    chattyLevel: 'Normal',
    activeLesson: null,
    lessonStepIndex: 0,
    isCarrying: false
};

// Dragging State
let dragging = null;
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

// DOM Elements
const screens = {
    splash: document.getElementById('splash-screen'),
    user: document.getElementById('user-screen'),
    app: document.getElementById('app-screen')
};

// Initialisation
function init() {
    setupEventListeners();
    renderApp();
    if (state.currentUser) {
        showScreen('app');
    }
}

function setupEventListeners() {
    document.getElementById('btn-start').addEventListener('click', () => {
        warmupAudio();
        showScreen('user');
        speak("Hello! Who is playing with the abacus today?");
    });

    document.getElementById('btn-hear-prompt').addEventListener('click', () => {
        speak("Hello! Who is playing with the abacus today?");
    });

    document.querySelectorAll('.btn-user').forEach(btn => {
        btn.addEventListener('click', () => {
            state.currentUser = btn.dataset.user;
            localStorage.setItem('abacus_user', state.currentUser);
            showScreen('app');
        });
    });

    document.getElementById('btn-change-user').addEventListener('click', () => {
        state.currentUser = null;
        localStorage.removeItem('abacus_user');
        showScreen('user');
    });

    document.getElementById('toggle-voice').addEventListener('click', (e) => {
        state.voiceEnabled = !state.voiceEnabled;
        e.target.classList.toggle('on', state.voiceEnabled);
        e.target.textContent = state.voiceEnabled ? 'On' : 'Off';
    });

    document.getElementById('toggle-sound').addEventListener('click', (e) => {
        state.soundEnabled = !state.soundEnabled;
        e.target.classList.toggle('on', state.soundEnabled);
        e.target.textContent = state.soundEnabled ? 'On' : 'Off';
    });

    document.querySelectorAll('.lvl-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            state.chattyLevel = btn.dataset.lvl;
            document.querySelectorAll('.lvl-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    document.getElementById('btn-reset').addEventListener('click', resetAll);

    // Lesson Logic
    document.getElementById('btn-start-lesson').addEventListener('click', startLesson);
    document.getElementById('btn-quit-lesson').addEventListener('click', () => {
        state.activeLesson = null;
        renderApp();
    });
    document.getElementById('btn-check-lesson').addEventListener('click', checkLessonStep);
}

function showScreen(id) {
    Object.keys(screens).forEach(k => screens[k].classList.remove('active'));
    screens[id].classList.add('active');
    renderApp();
}

function warmupAudio() {
    if (audioCtx.state === 'suspended') audioCtx.resume();
}

function speak(text) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    const ukVoices = voices.filter(v => v.lang.startsWith('en-GB'));
    
    // Seek the "English Lady"
    const ladyVoice = ukVoices.find(v => v.name.includes('Google UK English Female')) ||
                      ukVoices.find(v => v.name.includes('Hazel')) ||
                      ukVoices.find(v => v.name.includes('Serena')) ||
                      ukVoices.find(v => v.name.includes('Female')) ||
                      ukVoices[0];

    if (ladyVoice) utterance.voice = ladyVoice;
    utterance.lang = 'en-GB';
    utterance.rate = 0.9;
    utterance.pitch = 1.1;
    window.speechSynthesis.speak(utterance);
}

function playClack(rowIndex = 0) {
    if (!state.soundEnabled) return;
    const now = audioCtx.currentTime;
    const baseFreqs = [1800, 800, 350, 140];
    const gains = [0.1, 0.22, 0.42, 0.65];
    const decays = [0.04, 0.12, 0.35, 0.7];

    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = rowIndex < 2 ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(baseFreqs[rowIndex] + Math.random() * 15, now);
    g.gain.setValueAtTime(gains[rowIndex], now);
    g.gain.exponentialRampToValueAtTime(0.001, now + decays[rowIndex]);
    osc.connect(g); g.connect(audioCtx.destination);
    osc.start(now); osc.stop(now + decays[rowIndex]);
}

function renderApp() {
    if (!state.currentUser) return;
    document.getElementById('user-badge').textContent = state.currentUser[0];
    document.getElementById('display-name').textContent = state.currentUser;
    
    const total = state.counts.reduce((acc, val, idx) => acc + val * COLUMN_MULTIPLIERS[idx], 0);
    document.getElementById('total-value').textContent = total;

    const breakdown = document.getElementById('column-breakdown');
    breakdown.innerHTML = COLUMN_NAMES.slice().reverse().map((name, i) => {
        const idx = 3 - i;
        return `<span>${name}: <b>${state.counts[idx]}</b></span>`;
    }).join('');

    renderAbacus();
    updateLessonUI();
}

function updateLessonUI() {
    const ui = document.getElementById('lesson-ui');
    const btn = document.getElementById('btn-start-lesson');
    if (state.activeLesson) {
        ui.classList.remove('hidden');
        btn.classList.add('hidden');
        const text = document.getElementById('lesson-text');
        if (state.lessonStepIndex === 0) text.textContent = "Clear the abacus to start!";
        if (state.lessonStepIndex === 1) text.textContent = "Move 2 beads to the left on the top row (Ones).";
        if (state.lessonStepIndex === 2) text.textContent = "Add 2 more beads to the left.";
    } else {
        ui.classList.add('hidden');
        btn.classList.remove('hidden');
    }
}

function renderAbacus() {
    const svg = document.getElementById('abacus-svg');
    svg.innerHTML = '';
    svg.setAttribute('viewBox', `0 0 ${CONFIG.width} ${CONFIG.height}`);

    // Definitions
    const defs = `
        <defs>
            <linearGradient id="woodGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#78350f"/><stop offset="50%" stop-color="#92400e"/><stop offset="100%" stop-color="#78350f"/></linearGradient>
            <linearGradient id="rodGradient" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#94a3b8"/><stop offset="50%" stop-color="#f1f5f9"/><stop offset="100%" stop-color="#94a3b8"/></linearGradient>
            <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur in="SourceAlpha" stdDeviation="2"/><feOffset dx="1" dy="1"/><feComponentTransfer><feFuncA type="linear" slope="0.3"/></feComponentTransfer><feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge></filter>
        </defs>
    `;
    svg.insertAdjacentHTML('beforeend', defs);

    // Frame
    const frame = `<rect x="0" y="0" width="${CONFIG.width}" height="${CONFIG.height}" fill="url(#woodGradient)" rx="20"/>
                   <rect x="${CONFIG.padding/3}" y="${CONFIG.padding/3}" width="${CONFIG.width-CONFIG.padding/1.5}" height="${CONFIG.height-CONFIG.padding/1.5}" fill="#451a03" rx="10"/>`;
    svg.insertAdjacentHTML('beforeend', frame);

    const rodSpacing = (CONFIG.height - CONFIG.padding * 2) / 4;
    const slotWidth = CONFIG.beadWidth + 3;

    state.counts.forEach((count, rowIdx) => {
        const y = CONFIG.padding + rowIdx * rodSpacing + rodSpacing / 2;
        const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
        
        // Rod
        const rod = `<rect x="${CONFIG.padding}" y="${y - CONFIG.rodThickness/2}" width="${CONFIG.width - CONFIG.padding*2}" height="${CONFIG.rodThickness}" fill="url(#rodGradient)" rx="3"/>`;
        const label = `<text x="${CONFIG.padding + 10}" y="${y - CONFIG.rodThickness*2}" class="rod-label" style="font-size:12px; font-weight:bold; fill:rgba(252,211,77,0.6); pointer-events:none;">${COLUMN_NAMES[rowIdx].toUpperCase()}</text>`;
        g.innerHTML = rod + label;

        // Interaction area
        const hitArea = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        hitArea.setAttribute('x', CONFIG.padding);
        hitArea.setAttribute('y', y - rodSpacing/2);
        hitArea.setAttribute('width', CONFIG.width - CONFIG.padding*2);
        hitArea.setAttribute('height', rodSpacing);
        hitArea.setAttribute('fill', 'transparent');
        hitArea.style.cursor = 'pointer';
        hitArea.addEventListener('pointerdown', (e) => onPointerDown(e, rowIdx));
        g.appendChild(hitArea);

        // Beads
        for (let i = 0; i < 10; i++) {
            const isOnLeft = i < count;
            const beadG = document.createElementNS("http://www.w3.org/2000/svg", "g");
            beadG.style.cursor = 'pointer';
            
            let tx = isOnLeft 
                ? CONFIG.padding + CONFIG.extraLeftPadding + i * slotWidth
                : CONFIG.width - CONFIG.padding - (10 - i) * slotWidth;
            
            if (dragging && dragging.col === rowIdx) {
                tx += dragging.offset;
            }

            beadG.setAttribute('transform', `translate(${tx}, ${y - CONFIG.beadHeight/2})`);
            beadG.style.transition = (dragging && dragging.col === rowIdx) ? 'none' : 'transform 0.3s ease-out';

            const color = COLUMN_COLORS[rowIdx];
            beadG.innerHTML = `
                <rect width="${CONFIG.beadWidth}" height="${CONFIG.beadHeight}" rx="10" fill="${color}" filter="url(#shadow)"/>
                <rect x="${CONFIG.beadWidth*0.1}" y="5" width="${CONFIG.beadWidth*0.8}" height="6" rx="3" fill="white" fill-opacity="0.2"/>
            `;

            beadG.addEventListener('click', (e) => {
                if (dragging && Math.abs(dragging.offset) > 5) return;
                e.stopPropagation();
                updateCount(rowIdx, isOnLeft ? i : i + 1);
            });

            g.appendChild(beadG);
        }
        svg.appendChild(g);
    });
}

function onPointerDown(e, colIndex) {
    if (state.isCarrying) return;
    warmupAudio();
    const svg = document.getElementById('abacus-svg');
    const rect = svg.getBoundingClientRect();
    const x = e.clientX - rect.left;
    
    dragging = {
        col: colIndex,
        startX: x,
        initialCount: state.counts[colIndex],
        offset: 0,
        lastBeadDelta: 0
    };

    const moveHandler = (moveEvent) => {
        if (!dragging) return;
        const mx = moveEvent.clientX - rect.left;
        const deltaX = mx - dragging.startX;
        const slotWidth = CONFIG.beadWidth + 3;

        const maxR = (10 - dragging.initialCount) * slotWidth;
        const maxL = -dragging.initialCount * slotWidth;
        dragging.offset = Math.max(maxL, Math.min(maxR, deltaX));
        
        const beadDelta = Math.round(dragging.offset / slotWidth);
        if (beadDelta !== dragging.lastBeadDelta) {
            playClack(dragging.col);
            dragging.lastBeadDelta = beadDelta;
        }
        renderAbacus();
    };

    const upHandler = () => {
        if (dragging) {
            const beadDelta = Math.round(dragging.offset / slotWidth);
            const final = dragging.initialCount + beadDelta;
            updateCount(dragging.col, final);
            dragging = null;
            renderAbacus();
        }
        window.removeEventListener('pointermove', moveHandler);
        window.removeEventListener('pointerup', upHandler);
    };

    window.addEventListener('pointermove', moveHandler);
    window.addEventListener('pointerup', upHandler);
    const slotWidth = CONFIG.beadWidth + 3;
}

function updateCount(col, val) {
    if (state.isCarrying) return;
    const old = state.counts[col];
    state.counts[col] = Math.max(0, Math.min(10, val));
    
    if (state.counts[col] !== old) {
        playClack(col);
        checkCarry();
        provideFeedback(col);
        renderApp();
    }
}

function checkCarry() {
    for (let i = 0; i < 3; i++) {
        if (state.counts[i] >= 10) {
            state.isCarrying = true;
            setTimeout(() => {
                state.counts[i] = 0;
                state.counts[i+1]++;
                state.isCarrying = false;
                playClack(i + 1);
                if (state.voiceEnabled) speak("Ten beads turned into one!");
                checkCarry(); // Recursive for multiple carries
                renderApp();
            }, 400);
            return;
        }
    }
}

function provideFeedback(col) {
    const total = state.counts.reduce((acc, val, idx) => acc + val * COLUMN_MULTIPLIERS[idx], 0);
    const bubble = document.getElementById('feedback-bubble');
    
    let sentence = "";
    if (state.chattyLevel === 'Quiet') {
        sentence = `Total is ${total}.`;
    } else {
        sentence = `${state.currentUser}, you have ${state.counts[col]} on the ${COLUMN_NAMES[col].toLowerCase()} row. That makes ${total} altogether.`;
        if (state.chattyLevel === 'Chatty' && Math.random() > 0.7) {
            sentence += " Well done!";
        }
    }
    
    bubble.textContent = `"${sentence}"`;
    if (state.voiceEnabled) speak(sentence);
}

function resetAll() {
    state.counts = [0, 0, 0, 0];
    state.activeLesson = null;
    state.lessonStepIndex = 0;
    playClack(0);
    if (state.voiceEnabled) speak("Abacus cleared.");
    renderApp();
}

// Lesson Engine
function startLesson() {
    state.counts = [0, 0, 0, 0];
    state.activeLesson = '2plus2';
    state.lessonStepIndex = 0;
    speak("Let's learn 2 plus 2. First, make sure the abacus is clear.");
    renderApp();
}

function checkLessonStep() {
    if (state.activeLesson === '2plus2') {
        if (state.lessonStepIndex === 0) {
            state.lessonStepIndex = 1;
            speak(`Step one: ${state.currentUser}, please move 2 beads on the ones row to the left.`);
        } else if (state.lessonStepIndex === 1) {
            if (state.counts[0] === 2) {
                state.lessonStepIndex = 2;
                speak("Great! Now add 2 more beads on the same row.");
            } else {
                speak("Almost! You need exactly 2 beads on the ones row.");
            }
        } else if (state.lessonStepIndex === 2) {
            if (state.counts[0] === 4) {
                speak("Well done! 2 plus 2 equals 4 altogether. You're brilliant!");
                state.activeLesson = null;
            } else {
                speak("Count carefully! We want 4 beads on the left now.");
            }
        }
    }
    renderApp();
}

// Start the app
window.speechSynthesis.onvoiceschanged = () => {};
init();