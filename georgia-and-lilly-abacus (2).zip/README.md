
# Georgia and Lilly Abacus

A realistic, child-friendly abacus web application built for primary school mathematics teaching. 

## Features
- **User Choice**: Custom experience for Georgia or Lilly.
- **Realistic Abacus**: Wooden frame with metal rods and coloured beads.
- **Interactive**: Drag or tap beads to count.
- **UK English**: Spelling and voice synthesis follow UK conventions.
- **Carrying Logic**: Automatic "carry 10" logic to teach place value transitions (Tens, Hundreds, Thousands).
- **Voice Feedback**: Optional spoken numbers and encouragement.
- **Lesson Mode**: Step-by-step interactive lessons.
- **Privacy First**: No tracking, no analytics, no external calls. All preferences are stored locally in your browser.

## Deployment to GitHub Pages
1. Push this code to a new GitHub repository.
2. Go to **Settings** > **Pages**.
3. Under **Build and deployment**, set the source to **GitHub Actions** or **Deploy from a branch** (main).
4. Since this is a pure static app (via the single-page build provided), it will host perfectly.

*Note: This app stores user preferences (name, voice settings) in `localStorage` on your own device only.*
