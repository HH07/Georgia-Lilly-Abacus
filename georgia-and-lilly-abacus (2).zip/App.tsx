
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { User, Counts, ChattyLevel, ColumnType } from './types';
import { COLUMN_NAMES, COLUMN_MULTIPLIERS } from './constants';
import UserSelection from './components/UserSelection';
import Abacus from './components/Abacus';
import LessonManager from './components/LessonManager';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User>(() => {
    return (localStorage.getItem('abacus_user') as User) || null;
  });
  const [counts, setCounts] = useState<Counts>([0, 0, 0, 0]);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [chattyLevel, setChattyLevel] = useState<ChattyLevel>('Normal');
  const [activeLesson, setActiveLesson] = useState<string | null>(null);
  const [lessonStepIndex, setLessonStepIndex] = useState(0);
  const [isCarrying, setIsCarrying] = useState(false);

  const prevCountsRef = useRef<Counts>(counts);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Persistence
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('abacus_user', currentUser);
    }
  }, [currentUser]);

  // Audio Context Warm-up (Must be triggered by user gesture)
  const warmupAudio = useCallback(() => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  }, []);

  // Optimized Sound Effect Logic
  const playClack = useCallback((rowIndex: number = 0) => {
    if (!soundEnabled || !audioCtxRef.current) return;
    
    const ctx = audioCtxRef.current;
    const now = ctx.currentTime;

    // Row-specific audio parameters
    const baseFreqs = [1800, 800, 350, 140];
    const gains = [0.1, 0.22, 0.42, 0.65];
    const decays = [0.04, 0.12, 0.35, 0.7];
    const jitter = Math.random() * 15;

    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = rowIndex < 2 ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(baseFreqs[rowIndex] + jitter, now);
    
    gainNode.gain.setValueAtTime(gains[rowIndex], now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + decays[rowIndex]);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + decays[rowIndex]);

    if (rowIndex >= 2) {
      const bodyOsc = ctx.createOscillator();
      const bodyGain = ctx.createGain();
      
      bodyOsc.type = 'triangle';
      bodyOsc.frequency.setValueAtTime(baseFreqs[rowIndex] * 0.5, now);
      
      bodyGain.gain.setValueAtTime(gains[rowIndex] * 0.4, now);
      bodyGain.gain.exponentialRampToValueAtTime(0.001, now + decays[rowIndex] * 1.1);
      
      bodyOsc.connect(bodyGain);
      bodyGain.connect(ctx.destination);
      
      bodyOsc.start(now);
      bodyOsc.stop(now + decays[rowIndex] * 1.1);
    }
  }, [soundEnabled]);

  // Voice Feedback - Specifically seeking an "English Lady"
  const speak = useCallback((text: string) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Get all available voices
    const voices = window.speechSynthesis.getVoices();
    
    // Filter for UK English voices
    const ukVoices = voices.filter(v => v.lang.startsWith('en-GB'));
    
    /**
     * Preference order for "English Lady" voices:
     * 1. Google UK English Female (high quality)
     * 2. Microsoft Hazel (standard Windows female UK)
     * 3. Serena / Martha / Apple UK voices
     * 4. Any en-GB voice that contains 'Female'
     * 5. Fallback to the first en-GB voice available
     */
    const ladyVoice = ukVoices.find(v => v.name.includes('Google UK English Female')) ||
                      ukVoices.find(v => v.name.includes('Hazel')) ||
                      ukVoices.find(v => v.name.includes('Serena')) ||
                      ukVoices.find(v => v.name.includes('Female')) ||
                      ukVoices[0];

    if (ladyVoice) {
      utterance.voice = ladyVoice;
    }

    utterance.lang = 'en-GB';
    utterance.rate = 0.9;  // Slightly slower for clarity
    utterance.pitch = 1.1; // Slightly higher for a friendly "lady" tone
    
    window.speechSynthesis.speak(utterance);
  }, []);

  // Pre-load voices for browsers that fetch them asynchronously
  useEffect(() => {
    window.speechSynthesis.getVoices();
    const handleVoicesChanged = () => window.speechSynthesis.getVoices();
    window.speechSynthesis.addEventListener('voiceschanged', handleVoicesChanged);
    return () => window.speechSynthesis.removeEventListener('voiceschanged', handleVoicesChanged);
  }, []);

  const generateFeedback = useCallback((newCounts: Counts) => {
    if (!currentUser) return '';
    const total = newCounts.reduce((acc, val, idx) => acc + val * COLUMN_MULTIPLIERS[idx], 0);
    
    let changedColIndex = -1;
    for (let i = 0; i < 4; i++) {
      if (newCounts[i] !== prevCountsRef.current[i]) {
        changedColIndex = i;
        break;
      }
    }

    if (chattyLevel === 'Quiet') return `Total is ${total}.`;

    let sentence = '';
    if (changedColIndex !== -1) {
      const colName = COLUMN_NAMES[changedColIndex].toLowerCase();
      sentence = `${currentUser}, you have ${newCounts[changedColIndex]} on the ${colName} row. `;
    }
    sentence += `That makes ${total} altogether.`;

    if (chattyLevel === 'Chatty' && Math.random() > 0.7) {
      const encouragements = ["Great counting!", "Maths star!", "Well done!", "Brilliant!"];
      sentence += ` ${encouragements[Math.floor(Math.random() * encouragements.length)]}`;
    }
    return sentence;
  }, [currentUser, chattyLevel]);

  // Carry Logic
  useEffect(() => {
    const checkCarry = () => {
      const nextCounts = [...counts] as Counts;
      for (let i = 0; i < 3; i++) {
        if (nextCounts[i] >= 10) {
          nextCounts[i] = 0;
          nextCounts[i + 1] += 1;
          
          setIsCarrying(true);
          setTimeout(() => {
            setCounts(nextCounts);
            setIsCarrying(false);
            playClack(i + 1); 
            if (voiceEnabled) speak("Ten beads turned into one!");
          }, 400); 
          break; 
        }
      }
    };
    if (!isCarrying) checkCarry();
  }, [counts, isCarrying, voiceEnabled, speak, playClack]);

  const handleBeadChange = (columnIndex: number, newValue: number) => {
    if (isCarrying) return;
    const newCounts = [...counts] as Counts;
    newCounts[columnIndex] = newValue;
    setCounts(newCounts);
    const feedback = generateFeedback(newCounts);
    if (voiceEnabled) speak(feedback);
    prevCountsRef.current = newCounts;
  };

  const handleReset = () => {
    warmupAudio(); 
    setCounts([0, 0, 0, 0]);
    setActiveLesson(null);
    setLessonStepIndex(0);
    playClack(0);
    if (voiceEnabled) speak("Abacus cleared.");
  };

  const totalValue = counts.reduce((acc, val, idx) => acc + val * COLUMN_MULTIPLIERS[idx], 0);

  if (!currentUser) {
    return (
      <UserSelection 
        onSelect={(user) => {
          warmupAudio(); 
          setCurrentUser(user);
        }}
        speak={speak}
        warmupAudio={warmupAudio}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center p-4">
      <header className="w-full max-w-4xl bg-white/80 backdrop-blur-md rounded-2xl shadow-lg p-4 mb-6 flex flex-wrap items-center justify-between gap-4 border-b-4 border-amber-200">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-inner">
            {currentUser[0]}
          </div>
          <div>
            <h1 className="text-xl font-bold text-amber-900">Georgia & Lilly's Abacus</h1>
            <p className="text-sm text-amber-700">
              Using as <span className="font-bold">{currentUser}</span> 
              <button 
                onClick={() => { setCurrentUser(null); localStorage.removeItem('abacus_user'); }}
                className="ml-2 text-blue-600 underline hover:text-blue-800 transition-colors"
              >
                (change)
              </button>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-2 bg-amber-50 p-2 rounded-xl border border-amber-100">
            <span className="text-sm font-semibold text-amber-800">Voice:</span>
            <button
              onClick={() => { warmupAudio(); setVoiceEnabled(!voiceEnabled); }}
              className={`px-4 py-1 rounded-full text-sm font-bold transition-all ${voiceEnabled ? 'bg-green-500 text-white shadow-md' : 'bg-gray-200 text-gray-500'}`}
            >
              {voiceEnabled ? 'On' : 'Off'}
            </button>
          </div>

          <div className="flex items-center gap-2 bg-amber-50 p-2 rounded-xl border border-amber-100">
            <span className="text-sm font-semibold text-amber-800">Sound:</span>
            <button
              onClick={() => { warmupAudio(); setSoundEnabled(!soundEnabled); }}
              className={`px-4 py-1 rounded-full text-sm font-bold transition-all ${soundEnabled ? 'bg-green-500 text-white shadow-md' : 'bg-gray-200 text-gray-500'}`}
            >
              {soundEnabled ? 'On' : 'Off'}
            </button>
          </div>

          <div className="flex items-center gap-2 bg-amber-50 p-2 rounded-xl border border-amber-100">
            <span className="text-sm font-semibold text-amber-800">Level:</span>
            {(['Quiet', 'Normal', 'Chatty'] as ChattyLevel[]).map(level => (
              <button
                key={level}
                onClick={() => setChattyLevel(level)}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${chattyLevel === level ? 'bg-amber-500 text-white' : 'bg-white text-amber-700 border border-amber-200'}`}
              >
                {level}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="w-full max-w-4xl flex flex-col items-center gap-6">
        <div className="text-center animate-bounce-subtle">
          <div className="text-7xl md:text-8xl font-black text-amber-900 drop-shadow-md">
            {totalValue}
          </div>
          <div className="text-amber-700 font-semibold mt-2 flex gap-4 justify-center flex-wrap">
            {COLUMN_NAMES.slice().reverse().map((name, i) => {
              const actualIdx = 3 - i; 
              return (
                <span key={name}>{name}: <span className="text-amber-900 font-bold">{counts[actualIdx]}</span></span>
              );
            })}
          </div>
        </div>

        <div className="relative w-full max-w-[800px] aspect-[4/3] touch-none">
          <Abacus 
            counts={counts} 
            onCountChange={handleBeadChange} 
            isCarrying={isCarrying}
            highlightColumn={activeLesson ? 0 : null}
            playClack={playClack}
            warmupAudio={warmupAudio}
          />
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-md border-2 border-amber-100 w-full text-center min-h-[4rem] flex items-center justify-center italic text-amber-900">
          "{generateFeedback(counts)}"
        </div>

        <div className="flex flex-wrap gap-4 justify-center w-full">
           <LessonManager 
             currentUser={currentUser}
             counts={counts}
             onReset={handleReset}
             setCounts={setCounts}
             speak={speak}
             activeLesson={activeLesson}
             setActiveLesson={setActiveLesson}
             lessonStepIndex={lessonStepIndex}
             setLessonStepIndex={setLessonStepIndex}
           />
           
           <button
            onClick={handleReset}
            className="px-8 py-3 bg-red-100 text-red-700 font-bold rounded-2xl border-b-4 border-red-300 hover:bg-red-200 transition-colors flex items-center gap-2"
           >
             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
             Reset Everything
           </button>
        </div>
      </main>

      <footer className="mt-12 text-amber-700/50 text-xs text-center max-w-lg">
        Georgia and Lilly Abacus - Designed for learning. Works offline.
      </footer>
    </div>
  );
};

export default App;
