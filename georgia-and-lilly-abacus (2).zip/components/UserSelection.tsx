
import React, { useState, useEffect } from 'react';
import { User } from '../types';

interface Props {
  onSelect: (user: User) => void;
  speak: (text: string) => void;
  warmupAudio: () => void;
}

const UserSelection: React.FC<Props> = ({ onSelect, speak, warmupAudio }) => {
  const [hasInteracted, setHasInteracted] = useState(false);
  const introText = "Hello! Who is playing with the abacus today?";

  const handleStart = () => {
    warmupAudio();
    setHasInteracted(true);
    // Speak immediately after the user gesture
    speak(introText);
  };

  const handleManualSpeak = (e: React.MouseEvent) => {
    e.stopPropagation();
    warmupAudio();
    speak(introText);
  };

  // If the user hasn't clicked "Start" yet, show the splash screen
  if (!hasInteracted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-amber-50 wood-texture overflow-hidden">
        <div className="max-w-md w-full bg-white rounded-[3rem] shadow-2xl p-12 text-center border-8 border-amber-200 animate-in fade-in zoom-in duration-500 relative">
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-amber-100 rounded-full opacity-50 animate-pulse"></div>
          
          <h1 className="text-4xl font-black text-amber-900 mb-4">Georgia & Lilly's Abacus</h1>
          <p className="text-amber-700 font-semibold mb-10">Ready to learn some maths?</p>

          <button
            onClick={handleStart}
            className="w-32 h-32 bg-amber-500 hover:bg-amber-600 text-white rounded-full shadow-xl flex items-center justify-center mx-auto transition-transform hover:scale-110 active:scale-95 group"
          >
            <svg className="w-16 h-16 ml-2 fill-current" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
          
          <p className="mt-8 text-amber-500 font-bold animate-bounce">Tap to Start!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-amber-50 wood-texture overflow-hidden">
      <div className="max-w-md w-full bg-white rounded-[3rem] shadow-2xl p-10 text-center border-8 border-amber-200 animate-in slide-in-from-bottom-10 fade-in duration-500 relative">
        {/* Animated Background Decor */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-amber-100 rounded-full opacity-50 animate-pulse"></div>
        <div className="absolute -bottom-10 -left-10 w-24 h-24 bg-amber-50 rounded-full opacity-50 animate-pulse delay-700"></div>

        <h1 className="text-4xl font-black text-amber-900 mb-2">Hello!</h1>
        
        <div className="flex items-center justify-center gap-2 mb-8 group">
          <p className="text-xl text-amber-700 font-semibold">Who is playing today?</p>
          <button 
            onClick={handleManualSpeak}
            className="p-2 bg-amber-100 rounded-full hover:bg-amber-200 transition-colors text-amber-600 group-hover:scale-110 transition-transform"
            title="Hear question again"
          >
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M14 8.83v6.34L11.83 13H9v-2h2.83L14 8.83M16 4l-5 5H7v6h4l5 5V4z" />
              <path d="M18.5 12c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM16 2.5V4.6c2.89.86 5 3.54 5 6.4s-2.11 5.54-5 6.4v2.1c4-.9 7-4.5 7-8.5s-3-7.6-7-8.5z" />
            </svg>
          </button>
        </div>
        
        <div className="grid grid-cols-1 gap-6">
          <button
            onClick={() => onSelect('Georgia')}
            className="group relative bg-rose-500 hover:bg-rose-600 text-white text-3xl font-bold py-8 rounded-[2rem] shadow-lg border-b-8 border-rose-700 transition-all hover:-translate-y-1 active:translate-y-1 active:border-b-0"
          >
            <span className="flex items-center justify-center gap-3">
              <span className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-2xl">G</span>
              Georgia
            </span>
          </button>

          <button
            onClick={() => onSelect('Lilly')}
            className="group relative bg-sky-500 hover:bg-sky-600 text-white text-3xl font-bold py-8 rounded-[2rem] shadow-lg border-b-8 border-sky-700 transition-all hover:-translate-y-1 active:translate-y-1 active:border-b-0"
          >
            <span className="flex items-center justify-center gap-3">
              <span className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-2xl">L</span>
              Lilly
            </span>
          </button>
        </div>

        <p className="mt-8 text-amber-600 text-sm italic">
          Tap your name to start!
        </p>
      </div>
    </div>
  );
};

export default UserSelection;
