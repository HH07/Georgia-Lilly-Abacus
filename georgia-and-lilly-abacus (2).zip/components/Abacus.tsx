
import React, { useState, useCallback, useRef } from 'react';
import { Counts, ColumnType } from '../types';
import { ABACUS_CONFIG, COLUMN_COLORS, COLUMN_NAMES } from '../constants';

interface Props {
  counts: Counts;
  onCountChange: (columnIndex: number, newValue: number) => void;
  isCarrying: boolean;
  highlightColumn: number | null;
  playClack: (rowIndex: number) => void;
  warmupAudio: () => void;
}

const Abacus: React.FC<Props> = ({ counts, onCountChange, isCarrying, highlightColumn, playClack, warmupAudio }) => {
  const { frameWidth, frameHeight, padding, beadWidth, rodThickness } = ABACUS_CONFIG;
  const svgRef = useRef<SVGSVGElement>(null);
  
  const [dragging, setDragging] = useState<{ 
    col: number; 
    startX: number; 
    initialCount: number;
    currentOffset: number; 
    lastBeadDelta: number; 
  } | null>(null);

  const extraLeftPadding = 60; 
  const slotWidth = beadWidth + 3;

  const handlePointerDown = (e: React.PointerEvent, colIndex: number) => {
    if (isCarrying) return;
    
    // Warmup audio on every new interaction to ensure context isn't suspended by browser
    warmupAudio();

    const svg = svgRef.current;
    if (!svg) return;

    const rect = svg.getBoundingClientRect();
    const x = e.clientX - rect.left;
    
    setDragging({
      col: colIndex,
      startX: x,
      initialCount: counts[colIndex],
      currentOffset: 0,
      lastBeadDelta: 0
    });
    
    (e.target as Element).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragging || isCarrying) return;
    const svg = svgRef.current;
    if (!svg) return;

    const rect = svg.getBoundingClientRect();
    const x = e.clientX - rect.left;
    
    const deltaX = x - dragging.startX;
    
    const maxDeltaRight = (10 - dragging.initialCount) * slotWidth;
    const maxDeltaLeft = -dragging.initialCount * slotWidth;
    
    const constrainedDelta = Math.max(maxDeltaLeft, Math.min(maxDeltaRight, deltaX));
    const beadDelta = Math.round(constrainedDelta / slotWidth);

    // TRIGGER NOISE IMMEDIATELY
    if (beadDelta !== dragging.lastBeadDelta) {
      playClack(dragging.col);
      // Explicitly update lastBeadDelta inside the dragging object to prevent multiple sounds for one "slot"
      dragging.lastBeadDelta = beadDelta;
    }

    setDragging({
      ...dragging,
      currentOffset: constrainedDelta
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (dragging) {
      const beadDelta = Math.round(dragging.currentOffset / slotWidth);
      const finalCount = Math.max(0, Math.min(10, dragging.initialCount + beadDelta));
      
      onCountChange(dragging.col, finalCount);
      
      if (finalCount !== dragging.initialCount) {
        playClack(dragging.col);
      }
      
      setDragging(null);
      (e.target as Element).releasePointerCapture(e.pointerId);
    }
  };

  const rodSpacing = (frameHeight - padding * 2) / 4;

  return (
    <svg 
      ref={svgRef}
      viewBox={`0 0 ${frameWidth} ${frameHeight}`} 
      className={`w-full h-full drop-shadow-2xl rounded-xl transition-opacity ${isCarrying ? 'opacity-80' : 'opacity-100'}`}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
    >
      <defs>
        <linearGradient id="woodGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#78350f" />
          <stop offset="50%" stopColor="#92400e" />
          <stop offset="100%" stopColor="#78350f" />
        </linearGradient>
        <linearGradient id="rodGradient" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#94a3b8" />
          <stop offset="50%" stopColor="#f1f5f9" />
          <stop offset="100%" stopColor="#94a3b8" />
        </linearGradient>
        <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur in="SourceAlpha" stdDeviation="2" />
          <feOffset dx="1" dy="1" />
          <feComponentTransfer>
            <feFuncA type="linear" slope="0.3" />
          </feComponentTransfer>
          <feMerge>
            <feMergeNode />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      <rect x="0" y="0" width={frameWidth} height={frameHeight} fill="url(#woodGradient)" rx="20" />
      <rect x={padding/3} y={padding/3} width={frameWidth-padding/1.5} height={frameHeight-padding/1.5} fill="#451a03" rx="10" />

      {[0, 1, 2, 3].map((rowIdx) => {
        const y = padding + rowIdx * rodSpacing + rodSpacing / 2;
        const count = counts[rowIdx];
        const color = COLUMN_COLORS[rowIdx];
        const isHighlighted = highlightColumn === rowIdx;
        const isRowDragging = dragging?.col === rowIdx;

        return (
          <g key={rowIdx} onPointerDown={(e) => handlePointerDown(e, rowIdx)}>
            <rect
              x={padding}
              y={y - rodSpacing/2}
              width={frameWidth - padding * 2}
              height={rodSpacing}
              fill="transparent"
              className="cursor-pointer"
            />
            
            <rect
              x={padding}
              y={y - rodThickness / 2}
              width={frameWidth - padding * 2}
              height={rodThickness}
              fill="url(#rodGradient)"
              rx={3}
              pointerEvents="none"
            />

            <text
              x={padding + 10}
              y={y - rodThickness * 2}
              textAnchor="start"
              className="text-[12px] font-bold fill-amber-300 select-none uppercase tracking-widest opacity-60"
              pointerEvents="none"
            >
              {COLUMN_NAMES[rowIdx]}
            </text>

            {[...Array(10)].map((_, beadIdx) => {
              const isOnLeft = beadIdx < count;
              
              let targetX = isOnLeft 
                ? padding + extraLeftPadding + beadIdx * slotWidth
                : frameWidth - padding - (10 - beadIdx) * slotWidth;
              
              if (isRowDragging) {
                targetX += dragging.currentOffset;
              }
              
              return (
                <g 
                    key={beadIdx} 
                    className={`${isRowDragging ? '' : 'transition-all duration-300 ease-out'} cursor-pointer`}
                    style={{ transform: `translateX(${targetX}px) translateY(${y - ABACUS_CONFIG.beadHeight/2}px)` }}
                    onClick={(e) => {
                        if (isRowDragging && Math.abs(dragging.currentOffset) > 5) return;
                        e.stopPropagation();
                        playClack(rowIdx);
                        if (isOnLeft) {
                            onCountChange(rowIdx, beadIdx); 
                        } else {
                            onCountChange(rowIdx, beadIdx + 1); 
                        }
                    }}
                >
                    <rect
                        width={beadWidth}
                        height={ABACUS_CONFIG.beadHeight}
                        rx={10}
                        fill={color}
                        filter="url(#shadow)"
                        className={`${isHighlighted && !isOnLeft && beadIdx === count ? 'animate-pulse stroke-white stroke-2' : ''}`}
                    />
                    <rect
                        x={beadWidth * 0.1}
                        y={5}
                        width={beadWidth * 0.8}
                        height={6}
                        rx={3}
                        fill="white"
                        fillOpacity="0.2"
                    />
                </g>
              );
            })}
          </g>
        );
      })}
    </svg>
  );
};

export default Abacus;
