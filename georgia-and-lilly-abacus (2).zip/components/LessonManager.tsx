
import React from 'react';
import { Counts, User } from '../types';

interface Props {
  currentUser: User;
  counts: Counts;
  onReset: () => void;
  setCounts: React.Dispatch<React.SetStateAction<Counts>>;
  speak: (text: string) => void;
  activeLesson: string | null;
  setActiveLesson: (lesson: string | null) => void;
  lessonStepIndex: number;
  setLessonStepIndex: (index: number) => void;
}

const LessonManager: React.FC<Props> = ({ 
  currentUser, 
  counts, 
  onReset, 
  setCounts, 
  speak,
  activeLesson,
  setActiveLesson,
  lessonStepIndex,
  setLessonStepIndex
}) => {

  const startLesson2Plus2 = () => {
    onReset();
    setActiveLesson('2plus2');
    setLessonStepIndex(0);
    speak("Let's learn 2 plus 2. First, make sure the abacus is clear.");
  };

  const handleNextStep = () => {
    if (activeLesson === '2plus2') {
      if (lessonStepIndex === 0) {
        setLessonStepIndex(1);
        speak(`Step one: ${currentUser}, please move 2 beads on the ones row to the left.`);
      } else if (lessonStepIndex === 1) {
        // Ones is now index 0
        if (counts[0] === 2) {
            setLessonStepIndex(2);
            speak("Great! Now add 2 more beads on the same row.");
        } else {
            speak("Almost! You need exactly 2 beads on the ones row.");
        }
      } else if (lessonStepIndex === 2) {
        // Ones is now index 0
        if (counts[0] === 4) {
            speak("Well done! 2 plus 2 equals 4 altogether. You're brilliant!");
            setActiveLesson(null);
            setLessonStepIndex(0);
        } else {
            speak("Count carefully! We want 4 beads on the left now.");
        }
      }
    }
  };

  return (
    <div className="flex flex-col gap-4">
      {!activeLesson ? (
        <button
          onClick={startLesson2Plus2}
          className="px-8 py-3 bg-blue-500 text-white font-bold rounded-2xl border-b-4 border-blue-700 hover:bg-blue-600 transition-all flex items-center gap-2 shadow-lg"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
          Lesson: 2 plus 2
        </button>
      ) : (
        <div className="bg-blue-50 border-2 border-blue-200 p-4 rounded-2xl shadow-inner flex flex-col items-center gap-3">
          <div className="text-blue-800 font-bold uppercase text-xs tracking-widest">Active Lesson: 2 + 2</div>
          <div className="text-blue-900 font-semibold text-center">
            {lessonStepIndex === 0 && "Clear the abacus to start!"}
            {lessonStepIndex === 1 && "Move 2 beads to the left on the top row (Ones)."}
            {lessonStepIndex === 2 && "Add 2 more beads to the left."}
          </div>
          <div className="flex gap-2">
            <button
                onClick={handleNextStep}
                className="px-6 py-2 bg-green-500 text-white font-bold rounded-xl shadow-md hover:bg-green-600 transition-colors"
            >
                Check My Work
            </button>
            <button
                onClick={() => { setActiveLesson(null); setLessonStepIndex(0); }}
                className="px-6 py-2 bg-gray-200 text-gray-700 font-bold rounded-xl shadow-md hover:bg-gray-300 transition-colors"
            >
                Quit Lesson
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default LessonManager;
