
export type User = 'Georgia' | 'Lilly' | null;

export enum ColumnType {
  Thousands = 0,
  Hundreds = 1,
  Tens = 2,
  Ones = 3
}

export type Counts = [number, number, number, number];

export type ChattyLevel = 'Quiet' | 'Normal' | 'Chatty';

export interface LessonStep {
  instruction: string;
  targetCounts: Partial<Counts>;
  highlightColumns: ColumnType[];
  highlightBeads?: number; // Number of beads that should be on the left
}

export interface AppState {
  currentUser: User;
  counts: Counts;
  voiceEnabled: boolean;
  soundEnabled: boolean;
  chattyLevel: ChattyLevel;
  activeLesson: string | null;
  lessonStepIndex: number;
}
