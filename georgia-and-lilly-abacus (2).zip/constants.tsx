
import { ColumnType } from './types';

// Updated order: Ones (top), Tens, Hundreds, Thousands (bottom)
export const COLUMN_NAMES = ['Ones', 'Tens', 'Hundreds', 'Thousands'];
export const COLUMN_MULTIPLIERS = [1, 10, 100, 1000];
export const COLUMN_COLORS = [
  '#eab308', // Yellow (Ones)
  '#22c55e', // Green (Tens)
  '#3b82f6', // Blue (Hundreds)
  '#ef4444'  // Red (Thousands)
];

export const ABACUS_CONFIG = {
  frameWidth: 700, // Increased width for more rod space
  frameHeight: 500,
  padding: 60,     // Increased padding for more space on the left/right
  beadRadius: 18,
  beadWidth: 40,
  beadHeight: 35,
  rodThickness: 8,
};
